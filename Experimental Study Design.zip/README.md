
  # Experimental Study Design

  This is a code bundle for Experimental Study Design. The original project is available at https://www.figma.com/design/hc7ZprT0gZnhLKDlahLbdo/Experimental-Study-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  