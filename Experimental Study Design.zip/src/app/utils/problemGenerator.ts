import { Problem, ProblemDifficulty } from '../App';

let problemCounter = 0;

export function generateProblem(): Problem {
  problemCounter++;

  // Alternate between easy and hard to ensure equal distribution
  const difficulty: ProblemDifficulty = problemCounter % 2 === 1 ? 'easy' : 'hard';

  if (difficulty === 'easy') {
    return generateEasyProblem();
  } else {
    return generateHardProblem();
  }
}

function generateEasyProblem(): Problem {
  const type = Math.floor(Math.random() * 4); // 0: addition, 1: subtraction, 2: multiplication, 3: division

  let question = '';
  let answer = 0;

  switch (type) {
    case 0: // One-digit + two-digit addition
      const a1 = Math.floor(Math.random() * 9) + 1; // 1-9
      const b1 = Math.floor(Math.random() * 90) + 10; // 10-99
      question = `${a1} + ${b1}`;
      answer = a1 + b1;
      break;

    case 1: // Two-digit - one-digit subtraction
      const a2 = Math.floor(Math.random() * 90) + 10; // 10-99
      const b2 = Math.floor(Math.random() * 9) + 1; // 1-9
      question = `${a2} - ${b2}`;
      answer = a2 - b2;
      break;

    case 2: // One-digit × one-digit multiplication
      const a3 = Math.floor(Math.random() * 9) + 2; // 2-10
      const b3 = Math.floor(Math.random() * 9) + 2; // 2-10
      question = `${a3} × ${b3}`;
      answer = a3 * b3;
      break;

    case 3: // Simple division (ensuring whole numbers)
      const divisor = Math.floor(Math.random() * 8) + 2; // 2-9
      const quotient = Math.floor(Math.random() * 10) + 2; // 2-11
      const dividend = divisor * quotient;
      question = `${dividend} ÷ ${divisor}`;
      answer = quotient;
      break;
  }

  return {
    id: `easy_${problemCounter}`,
    question,
    answer,
    difficulty: 'easy'
  };
}

function generateHardProblem(): Problem {
  const type = Math.floor(Math.random() * 6); // All multi-step operations

  let question = '';
  let answer = 0;

  switch (type) {
    case 0: // (a + b) - c
      const a1 = Math.floor(Math.random() * 50) + 20; // 20-69
      const b1 = Math.floor(Math.random() * 50) + 20; // 20-69
      const c1 = Math.floor(Math.random() * 30) + 10; // 10-39
      question = `(${a1} + ${b1}) - ${c1}`;
      answer = (a1 + b1) - c1;
      break;

    case 1: // a - b + c
      const a2 = Math.floor(Math.random() * 50) + 100; // 100-149
      const b2 = Math.floor(Math.random() * 40) + 50; // 50-89
      const c2 = Math.floor(Math.random() * 40) + 30; // 30-69
      question = `${a2} - ${b2} + ${c2}`;
      answer = a2 - b2 + c2;
      break;

    case 2: // (a × b) + c
      const a3 = Math.floor(Math.random() * 8) + 3; // 3-10
      const b3 = Math.floor(Math.random() * 8) + 3; // 3-10
      const c3 = Math.floor(Math.random() * 30) + 10; // 10-39
      question = `(${a3} × ${b3}) + ${c3}`;
      answer = (a3 * b3) + c3;
      break;

    case 3: // (a × b) - c
      const a4 = Math.floor(Math.random() * 8) + 3; // 3-10
      const b4 = Math.floor(Math.random() * 8) + 3; // 3-10
      const c4 = Math.floor(Math.random() * 20) + 5; // 5-24
      question = `(${a4} × ${b4}) - ${c4}`;
      answer = (a4 * b4) - c4;
      break;

    case 4: // a + b × c (order of operations)
      const a5 = Math.floor(Math.random() * 30) + 20; // 20-49
      const b5 = Math.floor(Math.random() * 8) + 2; // 2-9
      const c5 = Math.floor(Math.random() * 8) + 2; // 2-9
      question = `${a5} + ${b5} × ${c5}`;
      answer = a5 + (b5 * c5);
      break;

    case 5: // (a ÷ b) + c
      const divisor5 = Math.floor(Math.random() * 6) + 4; // 4-9
      const quotient5 = Math.floor(Math.random() * 8) + 5; // 5-12
      const dividend5 = divisor5 * quotient5;
      const c5b = Math.floor(Math.random() * 30) + 10; // 10-39
      question = `(${dividend5} ÷ ${divisor5}) + ${c5b}`;
      answer = quotient5 + c5b;
      break;
  }

  return {
    id: `hard_${problemCounter}`,
    question,
    answer,
    difficulty: 'hard'
  };
}
