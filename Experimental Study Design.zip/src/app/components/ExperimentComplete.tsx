import { CheckCircle, Download } from 'lucide-react';
import { ExperimentData, Response } from '../App';

interface ExperimentCompleteProps {
  data: ExperimentData;
}

export function ExperimentComplete({ data }: ExperimentCompleteProps) {
  const calculateStats = (responses: Response[], condition: string, difficulty: 'easy' | 'hard') => {
    const filtered = responses.filter(
      r => r.condition === condition && r.difficulty === difficulty
    );
    const attempted = filtered.length;
    const correct = filtered.filter(r => r.isCorrect).length;
    const accuracy = attempted > 0 ? (correct / attempted) * 100 : 0;

    return { attempted, correct, accuracy };
  };

  const period1Condition = data.musicFirst ? 'music' : 'no-music';
  const period2Condition = data.musicFirst ? 'no-music' : 'music';

  // Calculate stats for all four conditions
  const allResponses = [...data.period1Responses, ...data.period2Responses];

  const musicEasy = calculateStats(allResponses, 'music', 'easy');
  const musicHard = calculateStats(allResponses, 'music', 'hard');
  const noMusicEasy = calculateStats(allResponses, 'no-music', 'easy');
  const noMusicHard = calculateStats(allResponses, 'no-music', 'hard');

  const exportSummary = () => {
    // Create summary CSV
    const headers = [
      'Participant_ID',
      'Condition_Order',
      'Audio_Condition',
      'Difficulty',
      'Problems_Attempted',
      'Problems_Correct',
      'Accuracy_Percent'
    ];

    const rows = [
      [data.participantId, data.musicFirst ? 'music_first' : 'silence_first', 'music', 'easy', musicEasy.attempted, musicEasy.correct, musicEasy.accuracy.toFixed(2)],
      [data.participantId, data.musicFirst ? 'music_first' : 'silence_first', 'music', 'hard', musicHard.attempted, musicHard.correct, musicHard.accuracy.toFixed(2)],
      [data.participantId, data.musicFirst ? 'music_first' : 'silence_first', 'no_music', 'easy', noMusicEasy.attempted, noMusicEasy.correct, noMusicEasy.accuracy.toFixed(2)],
      [data.participantId, data.musicFirst ? 'music_first' : 'silence_first', 'no_music', 'hard', noMusicHard.attempted, noMusicHard.correct, noMusicHard.accuracy.toFixed(2)]
    ];

    const csv = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    // Sanitize participant name for filename
    const safeName = data.participantId.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    a.download = `summary_${safeName}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-4xl w-full bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center gap-3 mb-6">
          <CheckCircle className="w-8 h-8 text-green-600" />
          <h1 className="text-2xl">Experiment Complete!</h1>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <p className="text-sm">
            Thank you for participating! Your responses have been recorded.
          </p>
        </div>

        {/* Summary Statistics */}
        <div className="mb-8">
          <h2 className="font-semibold mb-4">Results Summary - Participant: {data.participantId}</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Music Conditions */}
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium mb-3 text-blue-600">With Background Music</h3>

              <div className="space-y-3">
                <div className="bg-gray-50 rounded p-3">
                  <div className="flex justify-between items-center">
                    <span>Problems Attempted: {musicEasy.attempted + musicHard.attempted}</span>
                    <span className="font-semibold">
                      Accuracy: {(((musicEasy.correct + musicHard.correct) / (musicEasy.attempted + musicHard.attempted)) * 100 || 0).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* No Music Conditions */}
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-medium mb-3 text-gray-600">Without Background Music (Silence)</h3>

              <div className="space-y-3">
                <div className="bg-gray-50 rounded p-3">
                  <div className="flex justify-between items-center">
                    <span>Problems Attempted: {noMusicEasy.attempted + noMusicHard.attempted}</span>
                    <span className="font-semibold">
                      Accuracy: {(((noMusicEasy.correct + noMusicHard.correct) / (noMusicEasy.attempted + noMusicHard.attempted)) * 100 || 0).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Condition Order Info */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
          <div className="text-sm">
            <strong>Condition Order:</strong> {data.musicFirst ? 'Music first, then silence' : 'Silence first, then music'}
          </div>
        </div>

        {/* Export Options */}
        <div className="space-y-3">
          <button
            onClick={exportSummary}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <Download className="w-5 h-5" />
            Export Summary Statistics (CSV)
          </button>
        </div>

        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-center">
            <strong>Please send your results to:</strong> gabriela.dossantos@mail.utoronto.ca
          </p>
        </div>
      </div>
    </div>
  );
}