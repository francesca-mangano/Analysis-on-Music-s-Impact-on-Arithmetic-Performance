import { useState, useRef, useEffect } from 'react';
import { Volume2, Play, Pause } from 'lucide-react';

interface VolumeCalibrationProps {
  onComplete: () => void;
}

export function VolumeCalibration({ onComplete }: VolumeCalibrationProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const musicUrl = 'https://www.youtube.com/watch?v=3aH8PFwpJu4';
  const videoId = musicUrl.includes('v=')
    ? musicUrl.split('v=')[1].split('&')[0]
    : musicUrl.split('/').pop();

  const togglePlay = () => {
    if (iframeRef.current) {
      if (isPlaying) {
        // Reload iframe to stop
        const src = iframeRef.current.src;
        iframeRef.current.src = '';
        iframeRef.current.src = src.replace('autoplay=1', 'autoplay=0');
      } else {
        // Start playing
        iframeRef.current.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=1&loop=1&playlist=${videoId}`;
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <div className="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center gap-3 mb-6">
          <Volume2 className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl">Volume Calibration</h1>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <h2 className="font-semibold mb-3">Set Your Study Volume</h2>
          <p className="text-sm mb-4">
            Before starting the experiment, please listen to a sample of the background music that will play during one of the periods.
          </p>
          <ul className="space-y-2 text-sm">
            <li>• Click the play button below to hear the music</li>
            <li>• Adjust your device volume to match your usual study volume</li>
            <li>• This music will play during one of the experimental periods</li>
            <li>• Once you're comfortable with the volume, click "Continue to Experiment"</li>
          </ul>
        </div>

        <div className="mb-6">
          <div className="bg-gray-100 rounded-lg p-4 flex flex-col items-center gap-4">
            <button
              onClick={togglePlay}
              className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-5 h-5" />
                  Pause Sample
                </>
              ) : (
                <>
                  <Play className="w-5 h-5" />
                  Play Sample
                </>
              )}
            </button>

            {isPlaying && (
              <div className="text-sm text-gray-600 flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                <span>Music playing...</span>
              </div>
            )}

            {/* YouTube iframe for audio playback - hidden */}
            <iframe
              ref={iframeRef}
              width="0"
              height="0"
              src={`https://www.youtube.com/embed/${videoId}?controls=0&loop=1&playlist=${videoId}`}
              title="Music Sample"
              allow="autoplay; encrypted-media"
              style={{ display: 'none' }}
            />
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
          <p className="text-sm">
            <strong>Note:</strong> Make sure your volume is comfortable for extended listening. The same volume will be used during the music period of the experiment.
          </p>
        </div>

        <button
          onClick={onComplete}
          className="w-full bg-green-600 text-white py-3 rounded-lg font-medium hover:bg-green-700 transition-colors"
        >
          Continue to Experiment
        </button>
      </div>
    </div>
  );
}
