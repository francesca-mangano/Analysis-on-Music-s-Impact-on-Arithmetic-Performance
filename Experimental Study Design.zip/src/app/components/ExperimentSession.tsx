import { useState, useEffect, useRef } from 'react';
import { Timer, Volume2, VolumeX, ArrowRight } from 'lucide-react';
import { ExperimentData, Response, Problem, MusicPreferences } from '../App';
import { generateProblem } from '../utils/problemGenerator';

interface ExperimentSessionProps {
  participantId: string;
  musicFirst: boolean;
  musicPreferences: MusicPreferences;
  initialData: ExperimentData;
  onComplete: (data: ExperimentData) => void;
}

type Period = 1 | 2;

export function ExperimentSession({
  participantId,
  musicFirst,
  musicPreferences,
  initialData,
  onComplete
}: ExperimentSessionProps) {
  const [period, setPeriod] = useState<Period>(1);
  const [timeRemaining, setTimeRemaining] = useState(90); // 1.5 minutes = 90 seconds
  const [currentProblem, setCurrentProblem] = useState<Problem | null>(null);
  const [userAnswer, setUserAnswer] = useState('');
  const [responses, setResponses] = useState<Response[]>([]);
  const [isBreak, setIsBreak] = useState(false);
  const [breakTime, setBreakTime] = useState(10);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const youtubePlayerRef = useRef<HTMLIFrameElement | null>(null);

  // Determine if current period has music
  const hasMusic = (period === 1 && musicFirst) || (period === 2 && !musicFirst);
  const condition = hasMusic ? 'music' : 'no-music';

  useEffect(() => {
    // Generate first problem
    setCurrentProblem(generateProblem());

    // Focus input
    inputRef.current?.focus();
  }, []);

  // Timer effect
  useEffect(() => {
    if (isBreak) {
      timerRef.current = setInterval(() => {
        setBreakTime((prev) => prev - 1);
      }, 1000);
    } else {
      timerRef.current = setInterval(() => {
        setTimeRemaining((prev) => prev - 1);
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [period, isBreak]);

  // Handle timer completion
  useEffect(() => {
    if (!isBreak && timeRemaining <= 0) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      handlePeriodEnd();
    }
  }, [timeRemaining, isBreak, period]);

  // Handle break completion
  useEffect(() => {
    if (isBreak && breakTime <= 0) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      startPeriod2();
    }
  }, [breakTime, isBreak]);

  // Music effect
  useEffect(() => {
    if (!isBreak) {
      if (hasMusic) {
        playBackgroundMusic();
      } else {
        stopBackgroundMusic();
      }
    }

    return () => {
      stopBackgroundMusic();
    };
  }, [hasMusic, isBreak]);

  const playBackgroundMusic = () => {
    if (!youtubePlayerRef.current) {
      // Select music based on preferences
      const musicUrl = getMusicUrl(musicPreferences);

      // Extract video ID from YouTube URL
      const videoId = musicUrl.includes('v=')
        ? musicUrl.split('v=')[1].split('&')[0]
        : musicUrl.split('/').pop();

      // Create YouTube iframe player
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.allow = 'autoplay';
      iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&loop=1&playlist=${videoId}&controls=0`;
      document.body.appendChild(iframe);
      youtubePlayerRef.current = iframe;
    }
  };

  const getMusicUrl = (prefs: MusicPreferences): string => {
    // Always use instrumental music without lyrics
    return 'https://www.youtube.com/watch?v=3aH8PFwpJu4';
  };

  const stopBackgroundMusic = () => {
    if (youtubePlayerRef.current) {
      // Remove YouTube iframe
      youtubePlayerRef.current.remove();
      youtubePlayerRef.current = null;
    }

    if (audioRef.current) {
      const audio = audioRef.current as any;

      if (audio.isWebAudio) {
        // Web Audio API cleanup
        audio.oscillators?.forEach((osc: any) => osc.stop());
        audio.audioContext?.close();
      } else {
        // HTML Audio cleanup
        audio.pause();
        audio.currentTime = 0;
      }

      audioRef.current = null;
    }
  };

  const handlePeriodEnd = () => {
    if (period === 1) {
      // Save period 1 data to parent before starting break
      const updatedData = {
        ...initialData,
        period1Responses: responses
      };
      onComplete(updatedData);

      // Start break
      setIsBreak(true);
      setBreakTime(10);
      stopBackgroundMusic();
    } else {
      // End experiment
      completeExperiment();
    }
  };

  const startPeriod2 = () => {
    setIsBreak(false);
    setPeriod(2);
    setTimeRemaining(90);
    setResponses([]); // Reset responses for period 2
    setCurrentProblem(generateProblem());
    setUserAnswer('');
    inputRef.current?.focus();
  };

  const completeExperiment = () => {
    stopBackgroundMusic();

    const finalData: ExperimentData = {
      ...initialData,
      period2Responses: responses,
      endTime: Date.now()
    };

    onComplete(finalData);
  };

  const handleSubmitAnswer = () => {
    if (!currentProblem || !userAnswer.trim()) return;

    const isCorrect = parseFloat(userAnswer) === currentProblem.answer;

    const response: Response = {
      problemId: currentProblem.id,
      question: currentProblem.question,
      difficulty: currentProblem.difficulty,
      userAnswer: userAnswer,
      correctAnswer: currentProblem.answer,
      isCorrect,
      timestamp: Date.now(),
      condition
    };

    const newResponses = [...responses, response];
    setResponses(newResponses);

    // Generate next problem
    setCurrentProblem(generateProblem());
    setUserAnswer('');
    inputRef.current?.focus();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmitAnswer();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (isBreak) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-gray-100">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-xl font-semibold mb-4">Break Time</h2>
          <p className="text-gray-600 mb-6">
            First period complete! Take a short break.
          </p>
          <div className="text-4xl font-bold text-blue-600 mb-4">
            {breakTime}s
          </div>
          <p className="text-sm text-gray-500">
            The second period will begin automatically
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                {hasMusic ? (
                  <>
                    <Volume2 className="w-5 h-5 text-blue-600" />
                    <span className="font-medium">Music Playing</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-5 h-5 text-gray-600" />
                    <span className="font-medium">Silence</span>
                  </>
                )}
              </div>
              <div className="text-sm text-gray-500">
                Period {period} of 2
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-gray-600" />
              <span className={`font-mono text-lg font-semibold ${
                timeRemaining <= 30 ? 'text-red-600' : 'text-gray-900'
              }`}>
                {formatTime(timeRemaining)}
              </span>
            </div>
          </div>
        </div>

        {/* Problem Display */}
        {currentProblem && (
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="text-3xl font-semibold mb-8 text-center py-8">
              {currentProblem.question}
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Your Answer
                </label>
                <input
                  ref={inputRef}
                  type="text"
                  inputMode="numeric"
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Enter your answer"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-xl"
                  autoFocus
                />
              </div>

              <button
                onClick={handleSubmitAnswer}
                disabled={!userAnswer.trim()}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-blue-600"
              >
                Submit Answer
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-6 text-center text-sm text-gray-500">
              Press Enter to submit
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
