import { useState } from 'react';
import { Music, Volume2, VolumeX } from 'lucide-react';
import { MusicPreferences } from '../App';

interface ExperimentSetupProps {
  onStart: (participantId: string, musicFirst: boolean, musicPreferences: MusicPreferences) => void;
}

export function ExperimentSetup({ onStart }: ExperimentSetupProps) {
  const [participantId, setParticipantId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (participantId.trim()) {
      // Randomly assign music first or silence first (50/50 chance)
      const musicFirst = Math.random() < 0.5;
      onStart(participantId.trim(), musicFirst, { genre: 'no-lyrics' });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center gap-3 mb-6">
          <Music className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl">Mental Arithmetic Experiment</h1>
        </div>

        <div className="space-y-6 mb-8">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h2 className="font-semibold mb-2">Experiment Overview</h2>
            <ul className="space-y-1 text-sm">
              <li>• Duration: 3 minutes total (two 1.5-minute periods)</li>
              <li>• You will solve arithmetic problems</li>
              <li>• One period will have background music, one will be silent</li>
              <li>• Perform all calculations mentally (no scratchwork)</li>
              <li>• Answer as many questions as possible</li>
            </ul>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <h2 className="font-semibold mb-2">Instructions</h2>
            <ul className="space-y-1 text-sm">
              <li>• Read each problem carefully</li>
              <li>• Type your answer in the input field</li>
              <li>• Press Enter or click Submit to move to the next problem</li>
              <li>• You can skip problems if needed</li>
              <li>• A timer will show remaining time for each period</li>
            </ul>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">
              Full Name
            </label>
            <input
              type="text"
              value={participantId}
              onChange={(e) => setParticipantId(e.target.value)}
              placeholder="Enter your full name"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Start Experiment
          </button>
        </form>
      </div>
    </div>
  );
}