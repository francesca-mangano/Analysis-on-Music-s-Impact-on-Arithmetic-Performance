import { useState, useEffect, useRef } from 'react';
import { ExperimentSetup } from './components/ExperimentSetup';
import { VolumeCalibration } from './components/VolumeCalibration';
import { ExperimentSession } from './components/ExperimentSession';
import { ExperimentComplete } from './components/ExperimentComplete';

export type ProblemDifficulty = 'easy' | 'hard';

export interface Problem {
  id: string;
  question: string;
  answer: number;
  difficulty: ProblemDifficulty;
}

export interface Response {
  problemId: string;
  question: string;
  difficulty: ProblemDifficulty;
  userAnswer: string;
  correctAnswer: number;
  isCorrect: boolean;
  timestamp: number;
  condition: string; // 'music' or 'no-music'
}

export interface MusicPreferences {
  genre: 'no-lyrics';
}

export interface ExperimentData {
  participantId: string;
  musicFirst: boolean;
  musicPreferences: MusicPreferences;
  period1Responses: Response[];
  period2Responses: Response[];
  startTime: number;
  endTime: number;
}

type ExperimentStage = 'setup' | 'calibration' | 'session' | 'complete';

export default function App() {
  const [stage, setStage] = useState<ExperimentStage>('setup');
  const [participantId, setParticipantId] = useState('');
  const [musicFirst, setMusicFirst] = useState(false);
  const [musicPreferences, setMusicPreferences] = useState<MusicPreferences>(({
    genre: 'no-lyrics'
  }));
  const [experimentData, setExperimentData] = useState<ExperimentData | null>(null);

  const handleStartExperiment = (id: string, musicConditionFirst: boolean, prefs: MusicPreferences) => {
    setParticipantId(id);
    setMusicFirst(musicConditionFirst);
    setMusicPreferences(prefs);
    setExperimentData({
      participantId: id,
      musicFirst: musicConditionFirst,
      musicPreferences: prefs,
      period1Responses: [],
      period2Responses: [],
      startTime: Date.now(),
      endTime: 0
    });
    setStage('calibration');
  };

  const handleCalibrationComplete = () => {
    setStage('session');
  };

  const handleExperimentComplete = (data: ExperimentData) => {
    setExperimentData(data);

    // Only move to complete stage if both periods are done (endTime is set)
    if (data.endTime > 0) {
      setStage('complete');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {stage === 'setup' && (
        <ExperimentSetup onStart={handleStartExperiment} />
      )}

      {stage === 'calibration' && (
        <VolumeCalibration onComplete={handleCalibrationComplete} />
      )}

      {stage === 'session' && experimentData && (
        <ExperimentSession
          participantId={participantId}
          musicFirst={musicFirst}
          musicPreferences={musicPreferences}
          initialData={experimentData}
          onComplete={handleExperimentComplete}
        />
      )}

      {stage === 'complete' && experimentData && (
        <ExperimentComplete data={experimentData} />
      )}
    </div>
  );
}